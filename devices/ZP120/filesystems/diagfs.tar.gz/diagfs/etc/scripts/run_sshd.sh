#!/bin/sh
# Copyright (c) 2019, Sonos, Inc.  All rights reserved.

exec /usr/sbin/telnetd
